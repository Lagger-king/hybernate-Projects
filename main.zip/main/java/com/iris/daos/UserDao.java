package com.iris.daos;


import java.util.List;

import com.iris.model.User;

public interface UserDao {


	public boolean registerCustomer(User cust) ;
	public User validateCustomers(int userId, String Password);
	public List<User> viewAllCustomers();

	public boolean deleteCustomer (int id);
	
 public	boolean updateCustomers(User cust);
 public User getCustomers(int id) ;
}
